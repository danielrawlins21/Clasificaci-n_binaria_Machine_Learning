"""Utilidades comunes del proyecto."""
